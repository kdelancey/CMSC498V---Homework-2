#!/bin/bash

./HW2_publicTests.test publicMap
./HW2_publicTests.test publicFold
./HW2_publicTests.test publicElems
./HW2_publicTests.test publicSplitHalf
./HW2_publicTests.test publicMerge
./HW2_publicTests.test publicMergeBy
./HW2_publicTests.test publicMergeSortBy
./HW2_publicTests.test publicMergeAll
./HW2_publicTests.test publicDescending
./HW2_publicTests.test publicAscending
./HW2_publicTests.test publicMinMax
